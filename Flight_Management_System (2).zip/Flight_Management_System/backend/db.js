require('dotenv').config();
const mysql = require('mysql2/promise');
module.exports = mysql.createPool({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:process.env.DB_NAME||'flight_management_system',waitForConnections:true,connectionLimit:10,decimalNumbers:true,dateStrings:true});
